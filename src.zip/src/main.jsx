import React, { useMemo, useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import {
  ChevronRight,
  MapPin,
  Menu,
  Search,
  Sparkles,
  Compass,
  Camera,
  X,
} from "lucide-react";
import { categories } from "./categories.js";
import CategoryPage from "./CategoryPage.jsx";
import "./styles.css";

/* ─── Mobile Menu ─── */
function MobileMenu({ open, onClose }) {
  useEffect(() => {
    if (open) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <>
      {/* backdrop */}
      <div
        onClick={onClose}
        style={{
          position: "fixed", inset: 0, zIndex: 98,
          background: "rgba(7, 63, 37, 0.55)",
          opacity: open ? 1 : 0,
          pointerEvents: open ? "auto" : "none",
          transition: "opacity 0.25s",
        }}
      />
      {/* drawer */}
      <nav
        aria-label="Menu principal"
        style={{
          position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 99,
          width: "min(300px, 85vw)",
          background: "var(--cream)",
          padding: "28px 24px",
          display: "flex", flexDirection: "column", gap: "8px",
          transform: open ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 0.28s cubic-bezier(.4,0,.2,1)",
          overflowY: "auto",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
          <strong style={{ color: "var(--forest-deep)", fontSize: "1.05rem" }}>STP Verde</strong>
          <button
            onClick={onClose}
            aria-label="Fechar menu"
            style={{ background: "none", border: "none", cursor: "pointer", color: "var(--forest-deep)", padding: 4 }}
          >
            <X size={22} />
          </button>
        </div>

        <p style={{ fontSize: "0.72rem", fontWeight: 800, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--forest)", margin: "0 0 8px" }}>
          Categorias
        </p>

        {categories.map(({ id, title, icon: Icon }) => (
          <Link
            key={id}
            to={`/categorias/${id}`}
            onClick={onClose}
            style={{
              display: "flex", alignItems: "center", gap: "12px",
              padding: "12px 14px", borderRadius: "14px",
              color: "var(--ink)", fontWeight: 700, fontSize: "0.93rem",
              textDecoration: "none", transition: "background 0.15s",
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = "rgba(88,185,87,0.12)"}
            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
          >
            <Icon size={18} style={{ color: "var(--forest)" }} />
            {title}
          </Link>
        ))}

        <div style={{ marginTop: "auto", borderTop: "1px solid var(--line)", paddingTop: "20px", display: "flex", flexDirection: "column", gap: "8px" }}>
          <a href="#servicos" onClick={onClose} style={{ color: "var(--muted)", fontSize: "0.9rem", fontWeight: 700, textDecoration: "none" }}>Serviços</a>
          <a href="#experiencias" onClick={onClose} style={{ color: "var(--muted)", fontSize: "0.9rem", fontWeight: 700, textDecoration: "none" }}>Experiências</a>
          <a href="#contacto" onClick={onClose} style={{ color: "var(--muted)", fontSize: "0.9rem", fontWeight: 700, textDecoration: "none" }}>Contacto</a>
        </div>
      </nav>
    </>
  );
}

/* ─── Home Page ─── */
function HomePage() {
  const [active, setActive] = useState("todos");
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const visibleCategories = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return categories
      .filter((category) => active === "todos" || category.id === active)
      .map((category) => ({
        ...category,
        services: category.services.filter(([name, description]) => {
          const haystack = `${name} ${description} ${category.title}`.toLowerCase();
          return !normalizedQuery || haystack.includes(normalizedQuery);
        }),
      }))
      .filter((category) => category.services.length > 0);
  }, [active, query]);

  const totalServices = categories.reduce((sum, category) => sum + category.services.length, 0);

  return (
    <main>
      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />

      <section className="hero" id="inicio">
        <nav className="nav" aria-label="Navegação principal">
          <a className="brand" href="#inicio" aria-label="STP Verde início">
            <img src="public/images/logotipo.jpeg" alt="STP Verde" />
          </a>
          <div className="navLinks">
            <a href="#servicos">Serviços</a>
            <a href="#experiencias">Experiências</a>
            <a href="#contacto">Contacto</a>
          </div>
          <button className="iconButton" aria-label="Abrir menu" onClick={() => setMenuOpen(true)}>
            <Menu size={20} />
          </button>
        </nav>

        <div className="heroGrid">
          <div className="heroCopy">
            <p className="eyebrow">
              <MapPin size={16} /> São Tomé e Príncipe
            </p>
            <h1>Descobre ilhas feitas de mar, cacau e histórias.</h1>
            <p className="lead">
              O melhor portal de São Tomé para encontrar e publicitar alojamentos, transportes, tours, gastronomia,
              eventos, guias e comércio local em São Tomé e Príncipe.
            </p>
            <div className="searchBar">
              <Search size={21} />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Pesquisar serviços, atividades ou experiências..."
                aria-label="Pesquisar serviços"
              />
            </div>
            <div className="stats" aria-label="Resumo do portal">
              <span><strong>8</strong>Categorias</span>
              <span><strong>{totalServices}+</strong>Serviços</span>
              <span><strong>2</strong>Ilhas</span>
            </div>
          </div>

          <div className="heroVisual" aria-label="Paisagem tropical estilizada">
            <div className="sun" />
            <div className="photoCard cardOne">
              <span>Pico Cão Grande</span>
            </div>
            <div className="photoCard cardTwo">
              <span>Forte e litoral</span>
            </div>
            <div className="itinerary">
              <p>Roteiro em destaque</p>
              <strong>Praia Lagoa Azul, Pico Cão Grande e Museu Nacional</strong>
              <button onClick={() => navigate("/categorias/tours")}>
                Ver excursões <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="filters" aria-label="Filtros de categorias">
        <button className={active === "todos" ? "active" : ""} onClick={() => setActive("todos")}>
          Todos
        </button>
        {categories.map(({ id, title, icon: Icon }) => (
          <button key={id} className={active === id ? "active" : ""} onClick={() => setActive(id)}>
            <Icon size={17} /> {title}
          </button>
        ))}
      </section>

      <section className="content" id="servicos">
        <div className="sectionIntro">
          <p className="eyebrow">Catálogo turístico</p>
          <h2>Serviços que fazem sentido publicitar</h2>
          <p>
            Cada categoria foi pensada para receber parceiros, anúncios, reservas,
            contactos diretos e conteúdo editorial sobre experiências no arquipélago.
          </p>
        </div>

        <div className="categoryStack">
          {visibleCategories.map((category) => (
            <ServiceCategory key={category.id} category={category} />
          ))}
        </div>
      </section>

      <section className="experienceBand" id="experiencias">
        <div>
          <p className="eyebrow">Para operadores locais</p>
          <h2>Um site pronto para transformar curiosidade em reserva.</h2>
        </div>
        <div className="featureGrid">
          <article>
            <Sparkles size={22} />
            <h3>Vitrines de parceiros</h3>
            <p>Perfis para hotéis, restaurantes, guias, lojas e empresas de transporte.</p>
          </article>
          <article>
            <Compass size={22} />
            <h3>Roteiros temáticos</h3>
            <p>Experiências por interesse: natureza, cultura, gastronomia, ou aventura.</p>
          </article>
          <article>
            <Camera size={22} />
            <h3>Conteúdo visual</h3>
            <p>Galerias, chamadas editoriais e fotografias que destacam o melhor de STP.</p>
          </article>
        </div>
      </section>

      <footer className="footer" id="contacto">
        <div>
          <strong>STP Verde</strong>
          <p>Portal turístico para São Tomé e Príncipe.</p>
        </div>
        <a href="mailto:danielsousa@gmail.com">danielsousa@gmail.com</a>
      </footer>
    </main>
  );
}

/* ─── Service Category component ─── */
function ServiceCategory({ category }) {
  const Icon = category.icon;
  const navigate = useNavigate();

  return (
    <section className="category">
      <div className="categoryHeader">
        <div>
          <h3>
            <Icon size={21} /> {category.title}
          </h3>
          <p>{category.tagline}</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "14px", flexShrink: 0 }}>
          <span>{category.services.length} Serviços</span>
          <button
            onClick={() => navigate(`/categorias/${category.id}`)}
            style={{
              border: "1.5px solid var(--forest)",
              borderRadius: "999px",
              padding: "8px 18px",
              background: "transparent",
              color: "var(--forest-deep)",
              fontWeight: 800,
              fontSize: "0.82rem",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "5px",
              whiteSpace: "nowrap",
              transition: "background 0.16s, color 0.16s",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "var(--forest)"; e.currentTarget.style.color = "white"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--forest-deep)"; }}
          >
            Ver tudo <ChevronRight size={14} />
          </button>
        </div>
      </div>
      <div className="serviceGrid">
        {category.services.map(([name, description, ServiceIcon, label]) => (
          <article
            className="serviceCard"
            key={name}
            style={{ cursor: "pointer" }}
            onClick={() => navigate(`/categorias/${category.id}`)}
          >
            <ServiceIcon size={25} />
            <h4>{name}</h4>
            <p>{description}</p>
            <span>{label}</span>
          </article>
        ))}
      </div>
    </section>
  );
}

/* ─── App with Router ─── */
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/categorias/:id" element={<CategoryPage />} />
      </Routes>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root")).render(<App />);
